#!/usr/bin/env python3
# Note: This script runs dnsrecon

from dnsrecon import __main__

if __name__ == '__main__':
    __main__.main()
